### 1.1.0 ###
added config for where you TP when you die.

### 1.0.0 ###
When falling through map in the dungeon, you get tp-ed back to ship instead of dying.