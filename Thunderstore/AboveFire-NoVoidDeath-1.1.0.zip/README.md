# No death from botched TPs! #

This mod makes it so you don't die when you fall out the map in the facility.
You get TPed back to the ship instead. (or to the entrance, configurable)